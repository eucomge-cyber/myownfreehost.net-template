<?php include "signup.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo str_replace('www.', '', $_SERVER['HTTP_HOST']); ?> - Free Website Hosting</title>
    <meta name="description" content="Features: 5GB Disk space, Unlimited traffic, Daily hits limit 50,000, PHP version <?php echo phpversion(); ?>, Free subdomain .<?php echo str_replace('www.', '', $_SERVER['HTTP_HOST']); ?>, Unlimited Addon/Parked/Sub domains, Unlimited MySQL databases, Database size 300MB, Inodes 80,000 files, SSL/TLS, SiteBuilder, Ecommerce, Softaculous App installer, SEO tools, DNS SPF/CNAME records, Account upgrades, FTP Account 1, Online File manager, Free SSL Certificates, No Ads. Price: $0.00/mo.">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    
    <style>
        :root {
            --primary-color: #00c6ff;
            --secondary-color: #0072ff;
            --success-color: #2ECC71;
            --error-color: #E74C3C;
            --text-color: #ffffff;
            --input-bg: rgba(255, 255, 255, 0.05);
            --input-border: rgba(255, 255, 255, 0.15);
            --glass-bg: rgba(15, 15, 20, 0.6);
            --glass-border: rgba(255, 255, 255, 0.08);
        }

        body {
           margin: 0;
           padding: 20px;
           box-sizing: border-box;
           font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
           font-size: clamp(14px, 1.2vw, 16px);
           color: var(--text-color);
           display: flex;
           min-height: 100vh;
           background-color: #050505;
           position: relative;
        }

        .glass-container {
            margin: auto;
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 25px;
            width: 100%;
            max-width: 320px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), inset 0 0 0 1px rgba(255, 255, 255, 0.05);
            text-align: center;
            box-sizing: border-box;
            z-index: 1; 
            position: relative;
        }
        .logo  { 
            position: fixed;
            top: 25px;
            left: 25px;
            z-index: 9999;
            color: #ffffff;
            padding: 13px 28px;
            cursor: pointer;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            text-transform: uppercase;
            background-color: #111111;
            border-radius: 5px;
            opacity: 0.9;
          }   
        .login  { 
            position: fixed;
            top: 25px;
            right: 25px;
            z-index: 9999;
            background: linear-gradient(135deg, #141414 0%, #282828 100%);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 13px 28px;
            border-radius: 50px;
            cursor: pointer;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0.9;
          }
        .login:hover {
             background: linear-gradient(135deg, #1f1f1f 0%, #3a3a3a 100%);
             transform: translateY(-2px);
             box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5), 0 0 0 4px rgba(255, 255, 255, 0.05);
          }
        .login:active {
             transform: translateY(1px);
             box-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
          }
        .counter  { 
            position: fixed;
            bottom: 25px;
            left: 25px;
            z-index: 9999;
            color: #ffffff;
            padding: 13px 28px;
            cursor: pointer;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            text-transform: uppercase;
            background-color: #000000;
            border-radius: 5px;
            opacity: 0.9;
          }
        h2 {
            border-radius: 10px;
            padding-top: 5px;
            letter-spacing: 1px;
            color: #ffffff;
            text-shadow: 0 0 15px rgba(255, 255, 255, 0.3);
            cursor: pointer;
            font-size: 1.4rem;
            text-transform: uppercase;
        }
        .input-group {
            position: relative;
            margin-bottom: 15px;
            width: 100%;
        }

        input[type="text"],
        input[type="password"],
        input[type="email"] {
            width: 100%;
            padding: 14px 40px 14px 16px; 
            box-sizing: border-box;
            border: 1px solid var(--input-border);
            border-radius: 10px;
            background-color: var(--input-bg);
            color: #ffffff;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        #domainInput { padding-right: 110px; }
        
        input::placeholder { color: rgba(255, 255, 255, 0.5); }

        input:focus {
            outline: none;
            border-color: var(--primary-color);
            background-color: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 15px rgba(0, 198, 255, 0.2);
        }

        .domain-suffix {
            position: absolute;
            right: 36px;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.85rem;
            pointer-events: none;
            backdrop-filter: blur(4px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .status-icon-wrapper, .action-btn {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
            z-index: 10;
        }

        #statusIcon { right: 8px; }

        .action-btn svg { width: 20px; height: 20px; stroke: rgba(255,255,255,0.7); transition: 0.2s; }
        .action-btn:hover svg { stroke: #ffffff; }

        .captcha-img {
            width: 100%;
            height: auto;
            margin: 8px 2px 8px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
            transition: transform 0.3s ease;
            filter: contrast(1.1) brightness(0.9);
        }
        
        .captcha-img:hover {
            transform: scale(1.03);
        }

        .captcha-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            background-color: rgba(0, 0, 0, 0.2);
            border: 1px dashed var(--input-border);
            border-radius: 12px;
            padding-bottom: 10px;
            padding-left: 10px;
            padding-right: 10px;
            margin-bottom: 10px;
            width: 100%;
            box-sizing: border-box;
            position: relative;
        }

        .captcha-top-row {
            display: flex;
            width: 100%;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin: 2px;
        }

        .captcha-boxes {
            display: flex;
            gap: 6px;
            width: 100%;
        }

        input.captcha-box,
        .captcha-boxes input[type="text"] {
            width: 100% !important;
            min-width: 0 !important;
            height: 45px !important;
            padding: 0 !important;
            margin: 0 !important;
            text-align: center !important;
            font-size: 1.2rem !important;
            color: white;
            background-color: rgba(0, 0, 0, 0.4);
            border: 1px solid var(--input-border);
            border-radius: 8px;
            transition: all 0.3s ease;
            box-sizing: border-box;
            text-transform: uppercase;
            line-height: 45px;
        }

        input.captcha-box:focus,
        .captcha-boxes input[type="text"]:focus {
            outline: none;
            border-color: var(--primary-color);
            background-color: rgba(0, 198, 255, 0.05);
            box-shadow: 0 0 12px rgba(0, 198, 255, 0.25);
        }

        .refresh-btn {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.05);
            padding: 8px;
            margin: 2px;
            border-radius: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }

        .refresh-btn svg {
            width: 20px;
            height: 20px;
            stroke: #ffffff;
            transition: stroke 0.2s, transform 0.3s;
        }

        .refresh-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        .refresh-btn:hover svg {
            transform: rotate(90deg);
        }

        button[type="submit"] {
            margin-top: 5px;
            width: 100%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: #ffffff;
            padding: 15px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            box-shadow: 0 6px 20px rgba(0, 114, 255, 0.3);
            transition: all 0.3s ease;
        }

        button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 198, 255, 0.5);
        }

        button[type="submit"]:active {
            transform: translateY(1px);
            box-shadow: 0 4px 10px rgba(0, 198, 255, 0.3);
        }

        @keyframes spin { 100% { transform: rotate(360deg); } }
        .loading-svg { animation: spin 1s linear infinite; }
    </style>
</head>
<body>
    <span class="logo"><?php echo str_replace('www.', '', $_SERVER['HTTP_HOST']); ?><br><font color="gray"><small>Free Website Hosting</small></font></span>
<a class="login" href="https://cpanel.<?php echo str_replace('www.', '', $_SERVER['HTTP_HOST']); ?>">Login</a>
<div class="glass-container">
    <h2>Registration</h2>
    <form method="post" action="https://ifastnet.com/register.php">
        <div class="input-group">
            <input placeholder="Subdomain" type="text" id="domainInput" name="username" 
                   value="<?php $subdomain = $_GET['subdomain'] ?? ''; echo htmlspecialchars($subdomain); ?>" 
                   pattern="[a-z0-9]{4,16}" minlength="4" maxlength="16" required autocomplete="off">
            <span class="domain-suffix">.<?php echo str_replace('www.', '', $_SERVER['HTTP_HOST']); ?></span>
            <div id="statusIcon" class="status-icon-wrapper"></div>
        </div>

        <div class="input-group">
            <input placeholder="Password" type="password" id="password" name="password" minlength="6" maxlength="16" required>
            <button type="button" id="togglePassword" class="action-btn" aria-label="Show password">
                <svg id="eyeOpen" xmlns="http://w3.org" fill="none" viewBox="0 0 24 24" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                </svg>
                <svg id="eyeClose" xmlns="http://w3.org" fill="none" viewBox="0 0 24 24" stroke-width="1.5" style="display: none;">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.822 7.822 3 3m-3-3-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88" />
                </svg>
            </button>
        </div>

        <div class="input-group">
            <input placeholder="Email" type="email" id="emailInput" minlength="3" maxlength="40" name="email" 
                   pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
            <div id="emailStatusIcon" class="status-icon-wrapper"></div>
        </div>
        
        <div class="captcha-wrapper">
            <div class="captcha-top-row">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
                <img class="captcha-img" src="https://ifastnet.com/image.php?id=<?php echo urlencode($id); ?>" alt="Captcha">
                <button type="button" class="refresh-btn" onclick="window.location.reload();" title="Refresh">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
                    </svg>
                </button>
            </div>
        
            <!-- Hidden input field to hold full 5-character captcha for form submission -->
            <input type="hidden" name="number" id="captchaFull" required>
        
            <div class="captcha-boxes">
                <input type="text" class="captcha-box" maxlength="1" required autocomplete="off" data-index="0">
                <input type="text" class="captcha-box" maxlength="1" required autocomplete="off" data-index="1">
                <input type="text" class="captcha-box" maxlength="1" required autocomplete="off" data-index="2">
                <input type="text" class="captcha-box" maxlength="1" required autocomplete="off" data-index="3">
                <input type="text" class="captcha-box" maxlength="1" required autocomplete="off" data-index="4">
            </div>
        </div>
        <button type="submit">Register</button>
    </form>
</div>

<script>
    const freeIcon = `
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://w3.org/2000/svg">
        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM10 17.17L4.83 12L6.24 10.59L10 14.34L17.76 6.58L19.17 8L10 17.17Z" fill="#2ECC71"/>
    </svg>`;

    const busyIcon = `
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://w3.org/2000/svg">
        <path d="M12 2C6.47 2 2 6.47 2 12C2 17.53 6.47 22 12 22C17.53 22 22 17.53 22 12C22 6.47 17.53 2 12 2ZM17 15.59L15.59 17L12 13.41L8.41 17L7 15.59L10.59 12L7 8.41L8.41 7L12 10.59L15.59 7L17 8.41L13.41 12L17 15.59Z" fill="#E74C3C"/>
    </svg>`;

    const loadingIcon = `
    <svg class="loading-svg" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="10" stroke="rgba(255,255,255,0.1)" stroke-width="3" fill="none"/>
        <path d="M12 2C17.5228 2 22 6.47715 22 12" stroke="#00c6ff" stroke-width="3" stroke-linecap="round" fill="none"/>
    </svg>`;

    const domainInput = document.getElementById('domainInput');
    const statusIcon = document.getElementById('statusIcon');
    let typingTimer;

    domainInput.addEventListener('input', function() {
        clearTimeout(typingTimer);
        const subdomain = domainInput.value.trim().toLowerCase();
        
        if (subdomain === "") {
            statusIcon.innerHTML = "";
            return;
        }

        if (!/^[a-z0-9]+$/.test(subdomain)) {
            statusIcon.innerHTML = busyIcon;
            return;
        }

        statusIcon.innerHTML = loadingIcon;

        typingTimer = setTimeout(() => {
            checkDomainAvailability(subdomain);
        }, 600);
    });

    async function checkDomainAvailability(subdomain) {
        try {
            const response = await fetch(`check_subdomain.php?subdomain=${subdomain}`);
            const data = await response.json();
            statusIcon.innerHTML = (data.available === true) ? freeIcon : busyIcon;
        } catch (error) {
            console.error("Error:", error);
            statusIcon.innerHTML = ""; 
        }
    }

    const passwordInput = document.getElementById('password');
    const toggleButton = document.getElementById('togglePassword');
    const eyeOpen = document.getElementById('eyeOpen');
    const eyeClose = document.getElementById('eyeClose');

    toggleButton.addEventListener('click', () => {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            eyeOpen.style.display = 'none';
            eyeClose.style.display = 'block';
            toggleButton.setAttribute('aria-label', 'Hide password');
        } else {
            passwordInput.type = 'password';
            eyeOpen.style.display = 'block';
            eyeClose.style.display = 'none';
            toggleButton.setAttribute('aria-label', 'Show password');
        }
    });

    const emailInput = document.getElementById('emailInput');
    const emailStatusIcon = document.getElementById('emailStatusIcon');

    emailInput.addEventListener('blur', function() {
        let email = this.value.trim();

        if (email === "") {
            emailStatusIcon.innerHTML = "";
            return;
        }

        emailStatusIcon.innerHTML = loadingIcon;

        let xhr = new XMLHttpRequest();
        xhr.open('POST', 'check_email.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                if (xhr.responseText === 'valid') {
                    emailStatusIcon.innerHTML = freeIcon;
                } else {
                    emailStatusIcon.innerHTML = busyIcon;
                }
            }
        };
        
        xhr.send('email=' + encodeURIComponent(email));
    });

    const captchaBoxes = document.querySelectorAll('.captcha-box');
    const captchaFull = document.getElementById('captchaFull');

    // Combine all 5 boxes into hidden input `name="number"`
    function updateCaptchaValue() {
        let fullVal = '';
        captchaBoxes.forEach(box => {
            fullVal += box.value;
        });
        captchaFull.value = fullVal;
    }

    captchaBoxes.forEach((box, index) => {
        // Auto-advance focus to the next input box and convert to uppercase
        box.addEventListener('input', (e) => {
            box.value = box.value.toUpperCase();
            if (e.target.value.length >= 1 && index < captchaBoxes.length - 1) {
                captchaBoxes[index + 1].focus();
            }
            updateCaptchaValue();
        });

        // Auto-backspace behavior to navigate backwards
        box.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !box.value && index > 0) {
                captchaBoxes[index - 1].focus();
            }
        });

        // Paste support to fill all 5 inputs when user pastes code
        box.addEventListener('paste', (e) => {
            e.preventDefault();
            const pastedData = (e.clipboardData || window.clipboardData).getData('text').trim();
            if (pastedData) {
                const chars = pastedData.split('');
                captchaBoxes.forEach((b, i) => {
                    b.value = chars[i] || '';
                });
                const nextFocus = Math.min(chars.length, captchaBoxes.length - 1);
                if (captchaBoxes[nextFocus]) {
                    captchaBoxes[nextFocus].focus();
                }
                updateCaptchaValue();
            }
        });
    });
</script>
    <div class="counter">
<?php include "counter.php";  ?>
    </div>
</body>
</html>
