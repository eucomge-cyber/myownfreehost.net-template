<?php
if (isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'invalid';
        exit;
    }

    $domain = substr(strrchr($email, "@"), 1);

    if (checkdnsrr($domain, "MX")) {
        echo 'valid';
    } else {
        echo 'invalid';
    }
}
?>
