<script type="text/javascript">
var urlParams = new URLSearchParams(window.location.search);
if (urlParams.has('i')) {
    urlParams.delete('i');
    var newQuery = urlParams.toString();
    var newUrl = window.location.origin + window.location.pathname + (newQuery ? '?' + newQuery : '');
    window.location.href = newUrl;
}
</script>
<?PHP
$id = md5(rand(6000,PHP_INT_MAX));
?>
