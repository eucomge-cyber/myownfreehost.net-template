<?php
header('Content-Type: application/json');

if (isset($_GET['subdomain'])) {
    $subdomain = preg_replace("/[^a-z0-9]/", "", $_GET['subdomain']);
    
    if (strlen($subdomain) < 4) {
        echo json_encode(["available" => false]);
        exit;
    }

    $current_domain = str_replace('www.', '', $_SERVER['HTTP_HOST']);

    $full_domain = $subdomain . "." . $current_domain;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://" . $full_domain);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 6);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");
    
    $html_content = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($html_content === false || $http_code == 404) {
        echo json_encode(["available" => true]);
        exit;
    }
    $default_keywords = [
        "DNS Resolution Error"
    ];

    $is_default_page = false;
    foreach ($default_keywords as $keyword) {
        if (stripos($html_content, $keyword) !== false) {
            $is_default_page = true;
            break;
        }
    }

    if ($is_default_page) {
        echo json_encode(["available" => true]);
    } else {
        echo json_encode(["available" => false]);
    }

} else {
    echo json_encode(["error" => "No subdomain provided"]);
}
?>

